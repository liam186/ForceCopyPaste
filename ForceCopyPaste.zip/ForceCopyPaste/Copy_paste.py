import tkinter as tk
from tkinter import messagebox
import keyboard
import threading
import time

header_font = ("Helvetica", 10, "bold")
entry_font = ("Arial", 10)

# Function to type the text letter by letter
def type_text():
    text = text_entry.get()  # Get the text from the input field

    if not text:
        messagebox.showwarning("Empty Text", "Please enter some text first!")
        return

    # Type the text (in a separate thread to avoid blocking the GUI)
    def start_typing():
        for letter in text:
            keyboard.write(letter)  # Type one letter
            time.sleep(0.05)  # Add a small delay

    threading.Thread(target=start_typing, daemon=True).start()

# Create the GUI
root = tk.Tk()
root.title("Copy Paste Tool")
root.geometry("400x300")

# Set the background color to white
root.configure(bg="white")



# Labels and input fields
tk.Label(root, text="Enter your text:", font=header_font, bg="white", fg="black").pack(pady=10)
text_entry = tk.Entry(root, width=40, font=entry_font, bg="lightgray", fg="black")
text_entry.pack(pady=5)

# Label for the footer
tk.Label(root, text="Made by Liam", font=header_font, bg="white", fg="black").pack(pady=10)

# Button to start typing
start_button = tk.Button(root, text="Start Typing (Press F1)", font=header_font, bg="white", fg="black", command=type_text)
start_button.pack(pady=20)

# Set hotkey
keyboard.add_hotkey("F1", type_text)

# Start the GUI
root.mainloop()
